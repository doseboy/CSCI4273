Name: William Anderson
Date: October 20 2020
Assignment: PA2
Class: CSCI 4273
Professor: Sangtae Ha


INFORMATION ON PROGRAM:
This is a program to run an http server that can receive a GET request. I
used multithreaded approach. All the logic of each thread can be 
found in connection_handler(). 

HOW TO RUN:
1.Run make in /server directory and type "mv server www/"
2.Type "cd www/"
3.Type "./server <portno>"
4.Portno for example is 8888.
5.Go to google chrome and type "http://localhost:8888/index.html"
6.Have fun getting all the info you need from the website.
MAKE SURE TO PUT THE SERVER EXECUTABLE IN THE WWW/ DIRECTORY
